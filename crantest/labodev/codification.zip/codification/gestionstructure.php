<?php

$form_gestionstructure = "form_gestion_structure";
//Modification LIEU

$action_structure = '';

if (isset($_POST['codestructure']) && $_POST['codestructure'] == "codestructure")
{
    foreach($_POST as $postkey=>$postval)
    { 
        if ($postkey == "codestructure")
        {
            if(strlen($postkey)>=6 && substr($postkey,0,6)=="submit")
            { 
                $submit=$postkey;
                $pos4diese=strpos($postkey,'####');
                if ($pos4diese!==false)
                {
                    $submit=  substr($postkey,0,$pos4diese);
                    $pos3diese=strpos($submit,'###');
                    if($pos3diese!==false)
                    { 
                        $codification = substr($submit,$pos3diese+3);
                        if ($codification == "structure")
                        {
                            $submit=substr($postkey,0,$pos3diese);
                            $pos2diese=strpos($submit,'##');
                            if($pos2diese!==false)
                            { 
                                $codestructure=substr($submit,$pos2diese+2);
                                $submit=substr($submit,0,$pos2diese);
                                $posdiese=strpos($submit,"#");
                                if($posdiese!=false)
                                { 
                                    $action_structure=substr($submit,$posdiese+1);
                                }
                            }
                        }
                        else
                            break;   
                    }
                }

                else
                { 
                    $pos3diese=strpos($postkey,'###');
                    if($pos3diese!==false)
                    { 
                        $submit=substr($postkey,0,$pos3diese);
                        $pos2diese=strpos($submit,"##");
                        if($pos2diese!=false)
                        { 
                            $codification = substr($submit,$pos2diese+2);
                            if ($codification == "structure")
                            {
                                $submit=substr($postkey,0,$pos2diese);
                                $posdiese=strpos($submit,'#');
                                if($posdiese!==false)
                                { 
                                    $action_structure=substr($submit,$posdiese+1);
                                }
                            }
                            else
                                break;
                        }
                    }
                }
            }
        }
        else
        {
            break;
        }

    }

    
    // Traitement de l'action demand�e dans le POST
    if((isset($_POST["MM_update"])) && ($_POST["MM_update"] == $_SERVER['PHP_SELF'])) 
    {    if($action_structure=='creer' || $action_structure=='enregistrer')
        { 
            if(isset($_POST['codelib']) && $_POST['codelib']=='')
            { 
                $erreur='Libell&eacute; vide';
            }
        }
        if($erreur=='')
        { $affiche_succes=true;
                // on enregistre d'abord nouveau lieu
                if($action_structure=='creer')
                { 
                    $rs=mysql_query("select max(codestructure) as maxcodestructure from structure");

                    if (isset ($_POST["codelib"]))
                    {
                        $codelib = $_POST['codelib'];
                    }
                    else
                        $codelib = "";


                    if (isset ($_POST["libcourt_fr"]))
                    {
                        $libcourt_fr = mysql_real_escape_string(htmlspecialchars($_POST['libcourt_fr']));
                    }
                    else
                        $libcourt_fr = "";


                    if (isset ($_POST["liblong_fr"]))
                    {
                        $liblong_fr = mysql_real_escape_string(htmlspecialchars($_POST['liblong_fr']));
                    }
                    else
                        $liblong_fr = "";


                    if (isset ($_POST["libcourt_en"]))
                    {
                        $libcourt_en = mysql_real_escape_string(htmlspecialchars($_POST['libcourt_en']));
                    }
                    else
                        $libcourt_en = "";

                    if (isset ($_POST["liblong_en"]))
                    {
                        $liblong_en = mysql_real_escape_string(htmlspecialchars($_POST['liblong_en']));
                    }
                    else
                        $liblong_en = "";

                    if (isset ($_POST["esttheme"]))
                    {
                        $esttheme = mysql_real_escape_string(htmlspecialchars($_POST['esttheme']));
                    }
                    else
                        $esttheme = "";

                    if (isset ($_POST["estequipe"]))
                    {
                        $estequipe = mysql_real_escape_string(htmlspecialchars($_POST['estequipe']));
                    }
                    else
                        $estequipe = "";

                    if (isset ($_POST["date_deb"]))
                    {
                        $date_deb = mysql_real_escape_string(htmlspecialchars($_POST['date_deb']));
                    }
                    else
                        $date_deb = "";

                    if (isset ($_POST["date_fin"]))
                    {
                        $date_fin = mysql_real_escape_string(htmlspecialchars($_POST['date_fin']));
                    }
                    else
                        $date_fin = "";

                    $row_rs=mysql_fetch_assoc($rs);
                    $codestructure=str_pad((string)((int)$row_rs['maxcodestructure']+1), 2, "0", STR_PAD_LEFT);  
                    $query = "INSERT INTO lieu (codestructure,date_deb,date_fin,codelib,libcourt_fr,liblong_fr,libcourt_en,liblong_en,esttheme,estequipe) VALUES ('".$codestructure."',
                                                                                                                                                                            '".""."',
                                                                                                                                                                            '".$codelib."',
                                                                                                                                                                            '".$date_deb."',
                                                                                                                                                                            '".$date_fin."',
                                                                                                                                                                            '".$libcourt_fr."',
                                                                                                                                                                            '".$liblong_fr."',
                                                                                                                                                                            '".$libcourt_en."',
                                                                                                                                                                            '".$esttheme."', 
                                                                                                                                                                            '".$estequipe."')";
                    $result = mysql_query($query);
                    // Vérification du résultat
                    // Ceci montre la requête envoyée à MySQL ainsi que l'erreur. Utile pour déboguer.
                    if (!$result) {
                        $message  = 'Requete invalide : ' . mysql_error() . "\n";
                        $message .= 'Requete complete : ' . $query;
                        die($message);
                    }                                                 
                }
                else if($action_structure=='enregistrer')
                {	mysql_query("update lieu set libcourtlieu=".GetSQLValueString($_POST['libcourtlieu'], "text").", liblonglieu=".GetSQLValueString($_POST['liblonglieu'], "text").", lienlieuhttp=".GetSQLValueString($_POST['lienlieuhttp'], "text").
                                                                        " where codelieu=".GetSQLValueString($codelieu, "text")) or die(mysql_error());

                }
                else if($action_structure=='supprimer')

                {	

                    $test_code_structure = false;
                    $table = array();
                    $request = "select table_name from information_schema.columns where table_schema='crantest' and column_name like 'codestructure'";

                    $rs_request = mysql_query($request) or die(mysql_error());
                    while($row_rs_request=mysql_fetch_assoc($rs_request)) 
                    {
                        $table = $row_rs_request['table_name'];
                        if ($table == 'structure')
                        {

                        }
                        else
                        {
                            $rq = "SELECT * FROM $table WHERE codestructure = $codestructure";
                            $rs_rq = mysql_query($rq) or die(mysql_error());
                            $row_rs_rq = mysql_num_rows($rs_rq);

                            if ($row_rs_rq > 0)
                            {
                                $test_code_structure = true;
                                break;                        
                            }
                        }       
                    }

                    if (!$test_code_structure)
                        mysql_query("delete from lieu  where codestructure=".GetSQLValueString($codelieu, "text")) or die(mysql_error());
                    else
                    {
                        ?>
                        <script>alert("<?php echo 'Code structure d\351j\340 utilis\351 dans une autre table'; ?>")</script>
                        <?php
                    }

                }
        }
    }
}

if (empty($_POST['MM_update']) || isset($_POST['codestructure']) == "codestructure")
{
    $query_rs_structure = "SELECT codestructure,date_deb,date_fin,codelib,libcourt_fr,liblong_fr,libcourt_en,liblong_en,esttheme,estequipe FROM structure ORDER BY codestructure";
    $rs_structure = mysql_query($query_rs_structure) or die(mysql_error());

    //$tab_structure=array();
    while($row_rs_structure=mysql_fetch_assoc($rs_structure))
    {   
        $i=0;
        $table = array();
        $request = "select table_name from information_schema.columns where table_schema='crantest' and column_name = 'codestructure'";

        $rs_request = mysql_query($request) or die(mysql_error());
        while($row_rs_request=mysql_fetch_assoc($rs_request)) 
        {
            $table = $row_rs_request['table_name'];
            $codestructure = $row_rs_structure['codestructure'];
            if ($codestructure =="")
            {
                break;
            }
            
            else if ($table =="structure")
            {
                
            }
            
            else
            {
                $query_rs = "SELECT * FROM $table WHERE codestructure = $codestructure";
                $rs = mysql_query($query_rs) or die(mysql_error());
                $row_rs = mysql_num_rows($rs);

                if ($row_rs > 0)
                {
                    $tab_structure[$row_rs_structure['codestructure']] = $row_rs_structure;
                    $tab_structure[$row_rs_structure['codestructure']]['supprimable']=false;//par defaut  
                    break;
                }
                else 
                {
                    $tab_structure[$row_rs_structure['codestructure']] = $row_rs_structure;
                    $tab_structure[$row_rs_structure['codestructure']]['supprimable']=true;//par defaut
                }
            }
        }       
    }
    $_SESSION['tab_structure'] = $tab_structure;
}

?>