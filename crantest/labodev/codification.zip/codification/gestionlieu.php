<?php

$form_gestionlieu = "form_gestionlieu";

//Modification LIEU

$action_lieu = '';

if (isset($_POST['codelieu']) && $_POST['codelieu'] == "codelieu")
{
    foreach($_POST as $postkey=>$postval)
    { 
        if(strlen($postkey)>=6 && substr($postkey,0,6)=="submit")
        { 
            $submit=$postkey;
            $pos4diese=strpos($postkey,'####');
            if ($pos4diese!==false)
            {
                $submit=  substr($postkey,0,$pos4diese);
                $pos3diese=strpos($submit,'###');
                if($pos3diese!==false)
                { 
                    $codification = substr($submit,$pos3diese+3);
                    if ($codification == "lieu")
                    {
                        $submit=substr($postkey,0,$pos3diese);
                        $pos2diese=strpos($submit,'##');
                        if($pos2diese!==false)
                        { 
                            $codelieu=substr($submit,$pos2diese+2);
                            $submit=substr($submit,0,$pos2diese);
                            $posdiese=strpos($submit,"#");
                            if($posdiese!=false)
                            { 
                                $action_lieu=substr($submit,$posdiese+1);
                            }
                        }
                    }
                    else
                        break;   
                }
            }

            else
            { 
                $pos3diese=strpos($postkey,'###');
                if($pos3diese!==false)
                { 
                    $submit=substr($postkey,0,$pos3diese);
                    $pos2diese=strpos($submit,"##");
                    if($pos2diese!=false)
                    { 
                        $codification = substr($submit,$pos2diese+2);
                        if ($codification == "lieu")
                        {
                            $submit=substr($postkey,0,$pos2diese);
                            $posdiese=strpos($submit,'#');
                            if($posdiese!==false)
                            { 
                                $action_lieu=substr($submit,$posdiese+1);
                            }
                        }
                        else
                            break;
                    }
                }
            }
        }
    }
          
    // Traitement de l'action demandee dans le POST
    if((isset($_POST["MM_update"])) && ($_POST["MM_update"] == $_SERVER['PHP_SELF'])) 
    {   
        if($action_lieu=='creer' || $action_lieu=='enregistrer')
        { 
            if(isset($_POST['libcourtlieu']) && $_POST['libcourtlieu']=='')
            { 
                $erreur='Libell&eacute; vide';
            }
        }
        if($erreur=='')
        { $affiche_succes=true;
            // on enregistre d'abord nouveau lieu
            if($action_lieu=='creer')
            { 
                $Matchfound = "";
                $rs=mysql_query("select max(codelieu) as maxcodelieu from lieu");
                if (isset ($_POST["libcourtlieu"]))
                {
                    $lib_courtlieu = GetSQLValueString($_POST['libcourtlieu'],"text");
                    $query = "SELECT EXISTS( SELECT * FROM lieu WHERE libcourtlieu = $lib_courtlieu) AS Matchfound";
                    //$query = "SELECT * FROM lieu WHERE libcourtlieu = ".GetSQLValueString($_POST['libcourtlieu'], "text")."";
                    $result = mysql_query($query) or die(mysql_error());
                    $row_result = mysql_fetch_assoc($result);
                    $Matchfound = $row_result['Matchfound'];    
                }
                else
                {
                    $lib_courtlieu = "";
                }

                if (isset ($_POST["liblonglieu"]))
                {
                    $lib_longlieu = GetSQLValueString($_POST['liblonglieu'],"text");
                }
                else
                {
                    $lib_longlieu = "";
                }

                if (isset ($_POST["lienlieuhttp"]))
                {
                    $lien_lieuhttp = GetSQLValueString($_POST['lienlieuhttp'],"text");
                }
                else
                {
                    $lien_lieuhttp = "";
                }

                if (isset ($_POST["adresselieu"]))
                {
                    $adresse_lieu = GetSQLValueString($_POST['adresselieu'],"text");
                }
                else
                {
                    $adresse_lieu = "";
                }

                if ($Matchfound != "0")
                {
                    ?><script>alert("<?php echo 'Cet enregistrement existe d\351j\340 !!!'; ?>")</script><?php
                }
                else
                {
                    $row_rs=mysql_fetch_assoc($rs);
                    $codelieu=str_pad((string)((int)$row_rs['maxcodelieu']+1), 2, "0", STR_PAD_LEFT);  

                    $query = "INSERT INTO lieu (codelieu,date_deb,date_fin,libcourtlieu,liblonglieu,lienlieuhttp,adresselieu) VALUES ($codelieu,
                                                                                                                                        '',
                                                                                                                                        '',
                                                                                                                                        $lib_courtlieu, 
                                                                                                                                        $lib_longlieu,
                                                                                                                                        $lien_lieuhttp,
                                                                                                                                        $adresse_lieu)";
                    $result = mysql_query($query);
                    // Vérification du résultat
                    // Ceci montre la requête envoyée à MySQL ainsi que l'erreur. Utile pour déboguer.
                    if (!$result) 
                    {
                        $message  = 'Requête invalide : ' . mysql_error() . "\n";
                        $message .= 'Requête complète : ' . $query;
                        die($message);
                    }
                }

            }

            else if($action_lieu=='enregistrer')
            {	
            mysql_query("update lieu set libcourtlieu=".GetSQLValueString($_POST['libcourtlieu'], "text").", "
                                        . "liblonglieu=".GetSQLValueString($_POST['liblonglieu'], "text").", "
                                        . "lienlieuhttp=".GetSQLValueString($_POST['lienlieuhttp'], "text")." where codelieu=".GetSQLValueString($codelieu, "text")) or die(mysql_error());
            }
            else if($action_lieu=='supprimer')

            {	
                mysql_query("delete from lieu  where codelieu=".GetSQLValueString($codelieu, "text")) or die(mysql_error());

            }
        }
    }
}

if (empty($_POST['codelieu']) || isset($_POST['codelieu']) == "codelieu")
{
    $query_rs_lieu = "SELECT codelieu,libcourtlieu,liblonglieu,lienlieuhttp,adresselieu FROM lieu ORDER BY codelieu";
    $rs_lieu = mysql_query($query_rs_lieu) or die(mysql_error());
    
    //$tab_lieu = array();
    
    while($row_rs_lieu=mysql_fetch_assoc($rs_lieu))
    {   
        $i=0;
        $table = array();
        $request = "select table_name from information_schema.columns where table_schema='crantest' and column_name = 'codelieu'";

        $rs_request = mysql_query($request) or die(mysql_error());
        while($row_rs_request=mysql_fetch_assoc($rs_request)) 
        {
            $table = $row_rs_request['table_name'];
            $codelieu = $row_rs_lieu['codelieu'];
            if ($codelieu =="")
            {
                break;
            }
            else if ($table =="lieu")
            {
                
            }
            else
            {
                $query_rs = "SELECT * FROM $table WHERE codelieu = $codelieu";
                $rs = mysql_query($query_rs) or die(mysql_error());
                $row_rs = mysql_num_rows($rs);

                if ($row_rs > 0)
                {
                    $tab_lieu[$row_rs_lieu['codelieu']]=$row_rs_lieu;
                    $tab_lieu[$row_rs_lieu['codelieu']]['supprimable']=false;//par defaut 
                    break;
                }
                else 
                {
                    $tab_lieu[$row_rs_lieu['codelieu']]=$row_rs_lieu;
                    $tab_lieu[$row_rs_lieu['codelieu']]['supprimable']=true;//par defaut 
                }
            }
            $i++;

        }
    }
    $_SESSION['tab_lieu'] = $tab_lieu;
}
   
?>